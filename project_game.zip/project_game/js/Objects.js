
class Object extends Phaser.GameObjects.Sprite{
	constructor(scene, x, y, key) {
		super(scene, x, y, key);
		this.scene = scene;
		this.scene.add.existing(this);
		this.scene.physics.world.enableBody(this, 0);
	}
}

class Box extends Object {
	constructor(scene, x, y, key) {
		super(scene, x, y, key, "Box");
		this.position = false;
		this.scale_a;
	}

	create() {
		//��������� ��� ���������� ������ � ����������, �������� ����� �� ���������� Phaser
		const { LEFT, RIGHT, ONE, ENTER, DOWN } = Phaser.Input.Keyboard.KeyCodes;
		this.keys = this.input.keyboard.addKeys({
			left: LEFT,
			right: RIGHT,
			enter: ENTER,
			down: DOWN,
			one: ONE
		});
	}

	set_Scale(a) {
		this.body.scale_a = a;
		this.body.height = 505 * a;
    }

	get_height() {
		return 505 * this.body.scale_a;
    }

	moveLeft() {
		this.body.velocity.x = -300;
	}

	moveRight() {
		this.body.velocity.x = 300;
	}

	moveDown() {
		this.body.velocity.y = -200;
	}

	set_pos(a) {
		this.position = a;
	}

	get_vel() {
		return this.body.velocity.y;
	}

	fall() {
		this.body.allowGravity = true;
		this.body.collideWorldBounds = true;
		this.body.gravity.y = 50000;
	}

	stop_g() {
		this.body.allowGravity = false;
    }

	update() {
		this.body.setVelocity(0, 0);

		this.x = Phaser.Math.Clamp(this.x, 0, this.scene.game.config.width - 100);
		this.y = Phaser.Math.Clamp(this.y, 0, this.scene.game.config.height);
    }
}


class Fruit extends Object {
	constructor(scene, x, y, key) {
		super(scene, x, y, key, "Fruit");
	}

	move(a, b) {
		this.body.x = a;
		this.body.y = b;
    }
}