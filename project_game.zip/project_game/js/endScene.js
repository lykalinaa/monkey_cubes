class startScene extends Phaser.Scene {

    constructor() {
        super({ key: "endScene" });
    }

    create() {

    }

}