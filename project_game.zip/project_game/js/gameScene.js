//��� ����� ������ �������� ������. ���� ������, ����� ���� ��������
class gameScene extends Phaser.Scene {

    constructor() {
        super({ key: "gameScene", delay: 1000 });
        this.choice = 0;
        
        this.turn = 0;
        this.num_of_fruits = 0;
        this.fruit_a = false;

        this.my_fruits = 0;
        this.monkey_fruits = 0;

    }

    preload() {
        this.load.image("box", "pic/box.png");
        this.load.image("fruit", "pic/banana.png");
    }

    create() {

        //��������� ��� ���������� ������ � ����������, �������� ����� �� ���������� Phaser
        const { LEFT, RIGHT, ONE, TWO, THREE, FOUR, FIVE, ENTER, DOWN } = Phaser.Input.Keyboard.KeyCodes;
        this.keys = this.input.keyboard.addKeys({
            left: LEFT,
            right: RIGHT,
            enter: ENTER,
            down: DOWN,
            one: ONE,
            two: TWO,
            three: THREE,
            four: FOUR,
            five: FIVE
        });

        //���� ������������
        this.arr = new Array(Box);
        var k = 0.3;
        var x_box = 100;
        var y_box = this.game.config.height - 100;
        for (var i = 5; i > 0; i--) {
            this.box = new Box(
                this,
                x_box,
                y_box,
                "box"
            );
            this.box.setScale(k);
            this.box.set_Scale(k);
            this.arr.push(this.box);
            y_box -= (this.game.config.height - this.game.config.height * 0.2) * k;
            k -= 0.05;
        }


        //���� ����������
        this.comp = new Array(Box);
        var k = 0.3;
        var x_box = this.game.config.width - 100;
        var y_box = this.game.config.height - 100;
        for (var i = 5; i > 0; i--) {
            this.box = new Box(
                this,
                x_box,
                y_box,
                "box"
            );
            this.box.setScale(k);
            this.box.set_Scale(k);
            this.comp.push(this.box);
            y_box -= (this.game.config.height - this.game.config.height * 0.2) * k;
            k -= 0.05;

        }

        //������ �������� ����� ��� ��������� ����������
        this.cubes_comp = [0, 1, 2, 3, 4];
        this.number_of_boxes_comp = 5;

        this.comp_choice = 0;

        //��������� ������ ������
        this.fruit_height = [];
        this.t = 170;
        while(this.t != 430) {
            this.fruit_height.push(this.t);
            this.t += 10;

        }

        //������ ��������� (����������� � ������ ����� � �����)
        this.anim_height = 150;

        //��������� ������
        this.have_height = 0;


        //��������� ������
        this.need_win = this.fruit_appear();
        this.X = this.need_win[0];
        this.Y = this.fruit_height[Math.floor(Math.random() * 26)];
        this.fruit_a == true;

        this.s = 0;
    }

    fruit_appear() {
        this.fruit = new Fruit(
            this,
            Phaser.Math.Between(505 * 0.3 + 100, this.game.config.width - 500 * 0.5),
            this.fruit_height[Math.floor(Math.random() * 26)],
            "fruit"
        );
        this.fruit.setScale(0.15);
        return [this.fruit.x, this.fruit.y];
    }

    strategy(mas, len) {
        var a = Math.floor(Math.random() * len);
        console.log(mas[a]);
        return mas[a];
    }

    update() {

        if (this.num_of_fruits != 5) {
            if (this.fruit_a == false) {
                this.X = Phaser.Math.Between(505 * 0.3 + 100, this.game.config.width - 500 * 0.5);
                this.Y = this.fruit_height[Math.floor(Math.random() * 26)];
                this.fruit.x = this.X;
                this.fruit.y = this.Y;
                this.fruit_a = true;
                //this.fruit.update();
            }
            else {
                //���������� ����� �� ������
                for (var i = 0; i < 5; i++) {
                    this.arr[i + 1].update();
                    this.comp[i + 1].update();
                }
                this.fruit.update();
                //������� ������������

                if (this.game.config.height - this.Y - this.have_height > this.anim_height) {
                    if (this.turn == 0) {
                        //����� ������������� ������ �� ����: 5 - ����� ���������, 1 - ����� �������
                        if (this.choice == 0) {
                            if (this.keys.one.isDown)
                                this.choice = 1;
                            else if (this.keys.two.isDown)
                                this.choice = 2;
                            else if (this.keys.three.isDown)
                                this.choice = 3;
                            else if (this.keys.four.isDown)
                                this.choice = 4;
                            else if (this.keys.five.isDown)
                                this.choice = 5;
                        }
                        else if ((this.arr[this.choice].f == 0) && (this.choice != 0)) {
                            if ((this.arr[this.choice].position != true) && (this.choice != 0)) {
                                this.arr[this.choice].x = this.game.config.width / 2;
                                this.arr[this.choice].y = 100;
                                this.arr[this.choice].set_pos(true);
                            }
                            else if ((this.arr[this.choice].position == true)) {
                                //������������ ���������� ������ �� ������ ������ � �����
                                if (this.keys.right.isDown) {
                                    this.arr[this.choice].moveRight();
                                }
                                else if (this.keys.left.isDown) {
                                    this.arr[this.choice].moveLeft();
                                }
                                if (this.keys.enter.isDown) {
                                    this.s = 1;

                                }
                            }
                            if (this.s == 1) {
                                if (Math.abs(this.arr[this.choice].x - this.X) <= 75) {

                                    if (this.game.config.height - this.have_height - (this.arr[this.choice].get_height() / 2) >= this.arr[this.choice].y)
                                        this.arr[this.choice].y += 12;
                                    else {

                                        this.arr[this.choice].set_f(1);
                                        alert('you chose', this.choice, this.arr[this.choice].get_height());
                                        this.have_height += this.arr[this.choice].get_height();
                                        this.choice = 0;

                                        this.s = 0;
                                        this.turn = 1;
                                    }
                                }
                                else {
                                    if (this.game.config.height - this.arr[this.choice].get_height() / 2 >= this.arr[this.choice].y)
                                        this.arr[this.choice].y += 10;
                                    else {
                                        alert('cube is far from castle!');
                                        this.arr[this.choice].position = false;
                                        this.arr[this.choice].set_f(0);
                                        this.s = 0
                                    }
                                }
                            }
                        }
                        else if ((this.arr[this.choice].f != 0) && (this.choice != 0))
                            this.choice = 0;
                    }
                    else if (this.turn == 1) {
                        if (this.comp_choice == 0) {
                            this.comp_choice = this.strategy(this.cubes_comp, this.number_of_boxes_comp);
                            console.log(this.comp_choice);
                            this.comp[this.comp_choice].y = 100;
                            this.comp[this.comp_choice].x = this.X;
                        }
                        if (this.comp_choice != 0) {
                            if (this.game.config.height - this.have_height - this.comp[this.comp_choice].get_height() / 2 >= this.comp[this.comp_choice].y)
                                this.comp[this.comp_choice].y += 10;
                            else {
                                this.have_height += this.comp[this.comp_choice].get_height();
                                this.number_of_boxes_comp -= 1;
                                this.cubes_comp.splice(this.comp_choice);
                                this.comp_choice = 0;
                                this.turn = 0;
                            }
                        }
                    }
                }
                else {
                    if (this.turn == 1) {
                        alert('you take the fruit!');
                        this.my_fruits += 1;
                        this.turn = 0;
                    }
                    else if (this.turn == 0) {
                        alert('monkey take the fruit((');
                        this.monkey_fruits += 1;
                        this.turn = 1;
                    }

                    var k = 0.1;
                    var x_box_c = this.game.config.width - 100;
                    var x_box_u = 100;
                    var y_box = 100;
                    for (var i = 5; i > 0; i--) {
                        this.comp[i].x = x_box_c;
                        this.comp[i].y = y_box;

                        this.arr[i].x = x_box_u;
                        this.arr[i].y = y_box;
                        this.arr[i].set_pos(false);
                        this.arr[i].set_f(0);

                        y_box += (this.game.config.height) * k;
                        k += 0.05;
                    }


                    this.have_height = 0;
                    this.cubes_comp = [1, 2, 3, 4, 5];
                    this.number_of_boxes_comp = 5;
                    this.choice = 0;
                    this.comp_choice = 0;
                    this.fruit_a = false;
                    this.num_of_fruits += 1;
                    //this.turn = 0;
                }
            }
            
        }
        else {
            if (this.my_fruits > this.monkey_fruits) {
                alert('you won!! end of the game');
            }
            else {
                alert('monkey won(( end of the game');
            }
            console.log(this.my_fruits, this.monkey_fruits);
            this.scene.start('endScene');
        }
    }
}